This is a library for the Adafruit BME680 Humidity, Barometric Pressure, Temp and MOX Gas sensor

Designed specifically to work with the Adafruit BME680 Breakout 
 * http://www.adafruit.com/products/3660

These sensors use I2C or SPI to communicate, up to 4 pins are required to interface

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Check out the links above for our tutorials and wiring diagrams 
