var searchData=
[
  ['setgasheater',['setGasHeater',['../class_adafruit___b_m_e680.html#a2e6a61b5441c51bf5e44c3af3ee3fec8',1,'Adafruit_BME680']]],
  ['sethumidityoversampling',['setHumidityOversampling',['../class_adafruit___b_m_e680.html#af1f05d2f024e946c1d7cbe3fb90b0859',1,'Adafruit_BME680']]],
  ['setiirfiltersize',['setIIRFilterSize',['../class_adafruit___b_m_e680.html#a42f25a4f258aad9abad4abb6bd95ec77',1,'Adafruit_BME680']]],
  ['setpressureoversampling',['setPressureOversampling',['../class_adafruit___b_m_e680.html#a73a9467c838951a187a268172a2b5d8c',1,'Adafruit_BME680']]],
  ['settemperatureoversampling',['setTemperatureOversampling',['../class_adafruit___b_m_e680.html#a640ee0a0cb7ca57af30e8408260cc6e6',1,'Adafruit_BME680']]]
];
