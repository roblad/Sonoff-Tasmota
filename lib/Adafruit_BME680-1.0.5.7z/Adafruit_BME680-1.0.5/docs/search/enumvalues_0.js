var searchData=
[
  ['bme680_5fi2c_5fintf',['BME680_I2C_INTF',['../bme680__defs_8h.html#a2232c03d0c1282e976af41b39e1b87d6a8c5c46109186b1f476eafcb0fa608cf5',1,'bme680_defs.h']]],
  ['bme680_5fspi_5fintf',['BME680_SPI_INTF',['../bme680__defs_8h.html#a2232c03d0c1282e976af41b39e1b87d6a504bd691a4b57b0c914cc8c77bd696c3',1,'bme680_defs.h']]]
];
