var searchData=
[
  ['adafruit_5fbme680',['Adafruit_BME680',['../class_adafruit___b_m_e680.html#af147d564868b9eac61a2c7fcd8f614cd',1,'Adafruit_BME680::Adafruit_BME680(int8_t cspin=-1)'],['../class_adafruit___b_m_e680.html#a8e89aaed66497bb2dde7ab678aa81173',1,'Adafruit_BME680::Adafruit_BME680(int8_t cspin, int8_t mosipin, int8_t misopin, int8_t sckpin)']]]
];
