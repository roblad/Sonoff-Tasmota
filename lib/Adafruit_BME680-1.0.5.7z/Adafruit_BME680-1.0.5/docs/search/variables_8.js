var searchData=
[
  ['nb_5fconv',['nb_conv',['../structbme680__gas__sett.html#ad0fd15bcd071158faaa40037171cd798',1,'bme680_gas_sett']]],
  ['new_5ffields',['new_fields',['../structbme680__dev.html#a488698f8c1c548bb19ac1f8ee67cbadd',1,'bme680_dev']]]
];
